import React, { Component } from 'react'
import { connect } from 'react-redux'
import classNames from 'classnames'
import '../css/Controls.css'
import { app } from '../actions'

class Controls extends Component {
    constructor(props){
        super(props);
        
    }
    componentDidMount(){
        // this.props.dispatch(app.firstData())
        // this.props.dispatch(app.loadData())
        // console.log('DAta ===> ' + this.props.app.data)
        // console.log('DAta ===> ' + this.props.app.dataFirst)
    }
    _fun() {
        if (!this.props.Date) {
            return <div> Loading.. </div>
        } else {
            return <div> {this.props.Date.data.hospital[0].country}</div>
        }
    }

    render() {
        const controlsClass = classNames('Controls', {})

        return (
            <div className={controlsClass}>
                {this.props.state}
                <p>Redux state + component props: mohamed alaa</p>
                <div>
                    <pre>
                        {this._fun()}
                    </pre>
                </div>
                <button onClick={() => this.props.dispatch(app.firstData())}>
                    Dispatch loadData
          </button>
            </div>
        )
    }
}

const mapStateToProps = state => ({
    Date: state.app.dataFirst,
})
// const mapStateToProps = state => state

export default connect(mapStateToProps)(Controls)
